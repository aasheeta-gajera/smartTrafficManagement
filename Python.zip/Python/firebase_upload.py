import firebase_admin
from firebase_admin import credentials, db

cred = credentials.Certificate("smarttrafficmanagementsy.json")

if not firebase_admin._apps:
    firebase_admin.initialize_app(cred, {
        'databaseURL': 'https://smarttrafficmanagementsy-3f635-default-rtdb.firebaseio.com/'
    })

def upload_violation(number_plate, helmet_status, timestamp):
    ref = db.reference('TrafficViolations')
    ref.push({
        'number_plate': number_plate,
        'helmet': helmet_status,
        'timestamp': timestamp
    })
