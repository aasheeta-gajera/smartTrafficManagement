import cv2
from ocr import read_plate_text
from firebase_upload import upload_violation
import datetime

helmet_cascade = cv2.CascadeClassifier('haarcascade_helmet.xml')
plate_cascade = cv2.CascadeClassifier('haarcascade_russian_plate_number.xml')

cap = cv2.VideoCapture("http://192.168.94.90:8080/video")  # Replace with your IP

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    plates = plate_cascade.detectMultiScale(gray, 1.1, 4)
    helmets = helmet_cascade.detectMultiScale(gray, 1.1, 4)

    helmet_detected = len(helmets) > 0
    number_plate_text = None

    for (x, y, w, h) in plates:
        plate_img = frame[y:y+h, x:x+w]
        number_plate_text = read_plate_text(plate_img)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

    for (x, y, w, h) in helmets:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

    if number_plate_text:
        upload_violation(
            number_plate_text,
            "Yes" if helmet_detected else "No",
            str(datetime.datetime.now())
        )

    #cv2.imshow('Detection', frame)
    #if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()
