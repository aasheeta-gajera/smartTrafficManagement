import easyocr

reader = easyocr.Reader(['en'])

def read_plate_text(plate_img):
    results = reader.readtext(plate_img)
    for (bbox, text, prob) in results:
        if prob > 0.5:
            return text.strip()
    return None
